<?php

/**
 * Created by ModulesGarden.
 *
 * PHP version 7
 *
 * @author ModulesGarden <contact@modulesgarden.com>
 * @link https://www.modulesgarden.com/
 *
 *  * ******************************************************************
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *  * ******************************************************************
 */
// TEMPORARY DISABLED
/*
date_default_timezone_set("UTC");

$rootdir = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
require_once $rootdir.'/init.php';
require_once(dirname(dirname(__FILE__))."/vendor/autoload.php");

use Illuminate\Database\Capsule\Manager as Capsule;
use ModulesGarden\upCloudVm\Manager;

$tasks = Capsule::table('mod_upCloudVm_tasks')->where('done', '0')->get();

foreach ($tasks as $key => $task) {
    $data = json_decode($task->data, 1);
    if ($task->type == 'deleteTestServer') {
        $server  = Capsule::table('tblservers')
        ->where('id', $data['serverId'])
        ->first();

        $server = (array) $server;
        $server['password'] = decrypt($server['password']);

        $params = [
            'serverusername' =>  $server['username'],
            'serverpassword' => $server['password'],
            'serverhostname' => $server['hostname'],
            'serverip' => $server['ipaddress'],
            'serversecure' => $server['secure'],
        ];

        try {
            $manager  = new Manager($params);
            $manager->terminateTestServer($data['uuid']);
            Capsule::table('mod_upCloudVm_tasks')->where('id', $task->id)->update(['done' => 1]);
        } catch (\Throwable $th) {
            echo $th->getMessage();
        }
    }
}
 */
