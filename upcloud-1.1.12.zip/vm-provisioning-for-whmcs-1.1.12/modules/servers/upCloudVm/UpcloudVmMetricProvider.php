<?php
namespace ModulesGarden\upCloudVm;

use WHMCS\UsageBilling\Contracts\Metrics\MetricInterface;
use WHMCS\UsageBilling\Contracts\Metrics\ProviderInterface;
use WHMCS\UsageBilling\Metrics\Metric;
use WHMCS\UsageBilling\Metrics\Units\GigaBytes;
use WHMCS\UsageBilling\Metrics\Units\WholeNumber;
use WHMCS\UsageBilling\Metrics\Usage;

use Illuminate\Database\Capsule\Manager as Capsule;
use ModulesGarden\upCloudVm\Manager;

class UpcloudVmMetricProvider implements ProviderInterface
{
    private $moduleParams = [];
    public function __construct($moduleParams)
    {
        $this->moduleParams = $moduleParams;
    }

    public function metrics()
    {
        return [
            new Metric(
                'cpu',
                'CPU',
                MetricInterface::TYPE_PERIOD_MONTH,
                new WholeNumber('CPU')
            ),
            new Metric(
                'memory',
                'Memory',
                MetricInterface::TYPE_PERIOD_MONTH,
                new GigaBytes('Memory')
            ),
            new Metric(
                'backups',
                'Backups',
                MetricInterface::TYPE_PERIOD_MONTH,
                new GigaBytes('Backups')
            ),
        ];
    }

    public function usage()
    {
        $services = Capsule::table('tblhosting')
        ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
        ->where('tblhosting.domainstatus', 'Active')
        ->where('tblhosting.server', $this->moduleParams['serverid'])
        ->where('tblproducts.servertype', 'upCloudVm')->get(['tblhosting.id','tblhosting.packageid']);

        $usage = [];
      
        foreach ($services as $service) {
            $this->moduleParams['serviceid'] = $service->id;
            
            try {
                $manager = new Manager($this->moduleParams);
                $details = $manager->getServerDetails()['data'];
                $totalStorage = 0;
                $memoryGb = $details->server->memory_amount / 1024;
          
                $plan = $details->server->plan;
                $exploded = explode('x', $plan);
                $totalCpuGB = $exploded[0];
                  
                $totalBackupsGb = 0;
                $backups = $manager->getBackups();
                foreach ($backups['data'] as $b) {
                    $totalBackupsGb += $b[5];
                }
                $userData = [
                    'cpu' => $totalCpuGB,
                    'memory' => $memoryGb,
                    'backups' => $totalBackupsGb
                ];
                $usage[$service->id] = $this->wrapUserData($userData);
            } catch (\Exception $e) {
            }
        }
        return $usage;
    }
    
    public function tenantUsage($tenant)
    {
        try {
            $this->moduleParams['serviceid'] = $tenant;
            $manager = new Manager($this->moduleParams);
            $details = $manager->getServerDetails()['data'];
            $totalStorage = 0;
            $memoryGb = $details->server->memory_amount / 1024;
      
            $plan = $details->server->plan;
            $exploded = explode('x', $plan);
            $totalCpuGB = $exploded[0];
              
            $totalBackupsGb = 0;
            $backups = $manager->getBackups();
            foreach ($backups['data'] as $b) {
                $totalBackupsGb += $b[5];
            }
            $userData = [
                'cpu' => $totalCpuGB,
                'memory' => $memoryGb,
                'backups' => $totalBackupsGb
            ];
        } catch (\Exception $e) {
            return;
        }
        return $this->wrapUserData($userData);
    }

    private function wrapUserData($data)
    {
        $wrapped = [];
       
        foreach ($this->metrics() as $metric) {
            $key = $metric->systemName();
            if ($data[$key]) {
                $value = $data[$key];
                $metric = $metric->withUsage(
                    new Usage($value)
                );
            }
            
            $wrapped[] = $metric;
        }
        return $wrapped;
    }
}
