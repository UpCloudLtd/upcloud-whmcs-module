<?php

/**
 * Created by ModulesGarden.
 *
 * PHP version 7
 *
 * @author ModulesGarden <contact@modulesgarden.com>
 * @link https://www.modulesgarden.com/
 *
 *  * ******************************************************************
 *
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 *  * ******************************************************************
 */

use ModulesGarden\upCloudVm\Helper;
use ModulesGarden\upCloudVm\Manager;
use WHMCS\Database\Capsule;

add_hook('AdminProductConfigFields', 1, function () {
    if (!empty(App::getFromRequest("generateFields"))) {
        Helper::generateFields(App::getFromRequest("generateFields"));
    } else {
        $product = \WHMCS\Product\Product::find(filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT));
        if ($product->servertype == 'upCloudVm') {
            $product = \WHMCS\Product\Product::find(filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT));
            $output = '<table class="form module-settings" width="100%" cellspacing="2" cellpadding="3" border="0">\
            <tr style="width:100%;background-color:#BFBFBF;"> <td colspan="4">Default Options</td> </tr><tr>\
            <td class="fieldlabel" width="20%">Configurable Options </td><td class="fieldarea">\
            <a  href="configproducts.php?action=edit&id='.App::getFromRequest('id').'&tab=3&generateFields=configurable" >\
            Generate Default</a></td><td class="fieldlabel" width="20%">Custom Fields</td>\
            <td class="fieldarea"> <a href="configproducts.php?action=edit&id='.App::getFromRequest('id').'&tab=3&generateFields=custom" >\
            Generate Default</a></td><tr></tbody></table>';
            echo '<script>
                    $("#tblModuleSettings").before(\''.$output.'\');
                    </script>';
        }
    }
});

add_hook('ClientAreaFooterOutput', 1, function () {
    return '<style>#additionalinfo .text-left{ word-break: break-all;}</style>';
});

// TEMPORARY DISABLED
/* add_hook('ShoppingCartValidateProductUpdate', 1, function ($vars) {
    $product = \WHMCS\Product\Product::find($_SESSION['cart']['products'][$vars['i']]['pid']);
    if ($product->servertype == 'upCloudVm') {
        require_once dirname(__FILE__).'/vendor/autoload.php';
        // PRE CREATE
        try {
            $rel = Capsule::table('tblservergroupsrel')->where('groupid', $product->servergroup)->get();
            foreach ($rel as $r) {
                $server = Capsule::table('tblservers')->where('id', $r->serverid)->first();
                if ($server->active == 1) {
                    $server = (array) $server;
                    $server['password'] = decrypt($server['password']);
                    break;
                }
            }


            if ($server) {
                $params = [
                    'serverusername' =>  $server['username'],
                    'serverpassword' => $server['password'],
                    'serverhostname' => $server['hostname'],
                    'serverip' => $server['ipaddress'],
                    'serversecure' => $server['secure'],
                    'product' => $product,
                ];
                $manager = new Manager($params);
                $res = $manager->checkServerCheckout($vars['configoption']);
                if ($res['data']->server->uuid) {
                    // TERMINATE VM
                    Capsule::table('mod_upCloudVm_tasks')->insert(
                        [
                            'type' => 'deleteTestServer',
                            'data' => json_encode(['uuid' => $res['data']->server->uuid, 'serverId' => $server['id']]),
                            'startTime' => date('Y-m-d H:i:s'),
                            'done' => '0',
                        ]
                    );
                } else {
                    return $res['message'];
                }
            }
        } catch (\Throwable $th) {
            return($th->getMessage());
        }
    }
}); */

add_hook('ClientAreaPageProductDetails', 1, function ($vars) {
    if ($vars['modulename'] == 'upCloudVm') {
        return [
            'serverdata' => false,
            'ns1' => false,
            'ns2' => false
        ];
    }
});

add_hook('ClientAreaPage', 1, function ($vars) {
    if ($vars['templatefile'] == 'configureproduct') {
        $customCo = [];
        foreach ($vars['configurableoptions'] as $c) {
            $customCo[$c['optionname']] = $c['id'];
        }
        
        $size = 10;

        try {
            $product = Capsule::table('tblproducts')->where('id', $vars['productinfo']['pid'])->first();
     
            $server = Capsule::table('tblservers')
            ->where('tblservers.disabled', '0')
            ->first();
      
            $params['serverusername'] = $server->username;
            $params['serverpassword'] = decrypt($server->password);
            $params['serverhostname'] = $server->hostname;
            $params['serverip'] = $server->ipaddress;
            $params['serversecure'] = $server->secure;
    
            $manager = new Manager($params);
            $plans = $manager->getPlans()['data']->plans->plan;
            foreach ($plans as $plan) {
                if($plan->name == $product->configoption2)
                {
                    $size = $plan->storage_size;
                }
            
            }
        } catch (\Throwable $th) {}
       
        return ['customCo' => json_encode($customCo) , 'size' => $size];
    }
});
